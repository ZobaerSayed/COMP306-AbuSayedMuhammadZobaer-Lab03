.. _contact:

Contact
=======

The website `geohealthcheck.org <http://geohealthcheck.org>`_ is the main entry point.

All development is done via GitHub: see https://github.com/geopython/geohealthcheck.

Links
-----

- website: http://geohealthcheck.org
- GitHub: https://github.com/geopython/geohealthcheck
- Demo: https://demo.geohealthcheck.org
- Presentation: http://geohealthcheck.org/presentation
- Gitter Chat: https://gitter.im/geopython/GeoHealthCheck




