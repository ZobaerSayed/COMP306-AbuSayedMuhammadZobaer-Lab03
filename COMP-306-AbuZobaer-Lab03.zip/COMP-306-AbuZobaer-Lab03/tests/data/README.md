# Test Data

The test data in this directory consists of configurations, settings and
publically available OGC Web Services to facilitate testing.
