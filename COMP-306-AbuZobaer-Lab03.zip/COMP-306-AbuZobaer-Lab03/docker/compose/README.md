# GHC with Docker Compose

[Docker](https://www.docker.com/) is the fastest/recommended way to get GHC up and running.
[Docker Compose](https://docs.docker.com/compose/) is *a tool for defining and running multi-container Docker applications.*

Within this directory are *examples* for running GHC using Docker compose.
You should copy and adapt these for your own deployment.
