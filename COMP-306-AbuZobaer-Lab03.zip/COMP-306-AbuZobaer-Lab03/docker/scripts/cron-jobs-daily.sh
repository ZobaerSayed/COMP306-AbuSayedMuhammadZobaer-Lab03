# /bin/bash

source /venv/bin/activate .
python /GeoHealthCheck/GeoHealthCheck/models.py flush

