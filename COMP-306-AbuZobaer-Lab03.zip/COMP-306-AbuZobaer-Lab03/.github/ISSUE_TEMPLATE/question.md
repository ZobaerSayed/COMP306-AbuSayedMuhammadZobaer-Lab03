---
name: Question
about: I have a question
title: "(Put question subject here)"
labels: question
assignees: ''

---

If you have a specific question, for example on installation guidance or Plugin development, you can pose this below. It is probably easier/quicker to pose your question on the GeoHealthCheck Gitter Channel: https://gitter.im/geopython/GeoHealthCheck, an interactive chat-channel where GHC developers and users gather.
